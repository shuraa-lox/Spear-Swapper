package com.s0ftpulse.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;


public class SpearHelperClient implements ClientModInitializer {
	public class_304 swapAndClickKey;
	private int originalSlot = -1;

	public static final Logger LOGGER = LoggerFactory.getLogger("spearhelper");

	@Override
	public void onInitializeClient() {
		// Добавляем кнопку в меню настроеук управление

		class_2960 categoryId = class_2960.method_60655("spearhelper", "main");
		class_304.class_11900 customCategory = new class_304.class_11900(categoryId);

		swapAndClickKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.spearhelper.swap_click",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_R,
				customCategory
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.field_1724 == null || client.field_1687 == null) return;


			if (swapAndClickKey.method_1434()) {
				int spearSlot = findLungeSpear(client);
				if (originalSlot == -1) {
					originalSlot = client.field_1724.method_31548().method_67532();
				}

				if (client.field_1724.method_7261(0) >= 1.0f) {
					if (spearSlot != -1) {
						client.field_1724.method_31548().method_61496(spearSlot);

						try {
							java.lang.reflect.Method method = class_310.class.getDeclaredMethod("method_1536");
							method.setAccessible(true);
							method.invoke(client);
						} catch (Exception ignored) {}


						client.field_1724.method_31548().method_61496(originalSlot);


					}
				}else{
					LOGGER.info(String.valueOf(client.field_1724.method_7261(0)));
				}
			} else {
				originalSlot = -1;
			}
		});
	}

	private int findLungeSpear(class_310 client) {

		class_1792[] spears = {class_1802.field_63384, class_1802.field_63385, class_1802.field_63386, class_1802.field_63388, class_1802.field_63387, class_1802.field_63389, class_1802.field_63390};

		for (int i = 0; i < 9; i++) {
			class_1799 stack = client.field_1724.method_31548().method_5438(i);

			if (Arrays.asList(spears).contains(stack.method_7909())) {
				return i;
			}
		}

		return -1;
	}


}